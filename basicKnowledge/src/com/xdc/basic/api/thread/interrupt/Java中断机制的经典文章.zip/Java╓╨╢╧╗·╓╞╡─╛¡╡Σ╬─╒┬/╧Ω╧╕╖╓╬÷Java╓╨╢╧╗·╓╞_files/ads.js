/* 
 * This is just a dummy file used to try to detect AdBlockers
 */
var noAdblocker = true;
